package com.womensafety.app.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.view.KeyEvent
import com.womensafety.app.service.SosService

class VolumeButtonReceiver : BroadcastReceiver() {

    companion object {
        private var pressCount = 0
        private var lastPressTime = 0L
        private const val PRESS_INTERVAL_MS = 1000L
        private const val REQUIRED_PRESSES = 3
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_MEDIA_BUTTON) return

        val event = intent.getParcelableExtra<KeyEvent>(Intent.EXTRA_KEY_EVENT) ?: return
        if (event.keyCode != KeyEvent.KEYCODE_VOLUME_DOWN) return
        if (event.action != KeyEvent.ACTION_DOWN) return

        val now = System.currentTimeMillis()
        if (now - lastPressTime > PRESS_INTERVAL_MS) {
            pressCount = 0
        }
        lastPressTime = now
        pressCount++

        if (pressCount >= REQUIRED_PRESSES) {
            pressCount = 0
            SosService.start(context)
        }
    }
}
