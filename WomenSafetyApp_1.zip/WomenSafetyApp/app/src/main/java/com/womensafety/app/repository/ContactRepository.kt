package com.womensafety.app.repository

import android.content.Context
import com.womensafety.app.model.Contact

class ContactRepository(context: Context) {
    private val dao = SafetyDatabase.getInstance(context).contactDao()

    suspend fun getAllContacts(): List<Contact> = dao.getAllContacts()
    suspend fun insertContact(contact: Contact) = dao.insertContact(contact)
    suspend fun deleteContact(contact: Contact) = dao.deleteContact(contact)
    suspend fun updateContact(contact: Contact) = dao.updateContact(contact)
    suspend fun getContactCount(): Int = dao.getContactCount()
}
