package com.womensafety.app.service

import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.IBinder
import android.telephony.SmsManager
import androidx.core.app.NotificationCompat
import com.google.android.gms.location.*
import com.womensafety.app.R
import com.womensafety.app.repository.ContactRepository
import com.womensafety.app.ui.home.MainActivity
import com.womensafety.app.utils.LocationHelper
import kotlinx.coroutines.*

class SosService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private lateinit var contactRepository: ContactRepository

    companion object {
        const val CHANNEL_ID = "SOS_CHANNEL"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "STOP_SOS"

        fun start(context: Context) {
            val intent = Intent(context, SosService::class.java)
            context.startForegroundService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, SosService::class.java).apply {
                action = ACTION_STOP
            }
            context.startService(intent)
        }
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        contactRepository = ContactRepository(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startForeground(NOTIFICATION_ID, buildNotification())
        triggerSOS()
        return START_STICKY
    }

    private fun triggerSOS() {
        serviceScope.launch {
            val location = LocationHelper.getLastLocation(this@SosService, fusedLocationClient)
            val contacts = contactRepository.getAllContacts()
            val message = buildSosMessage(location)

            contacts.forEach { contact ->
                sendSms(contact.phone, message)
            }

            // Update Firebase with SOS status
            LocationHelper.updateFirebaseSOS(location, true)
        }
    }

    private fun buildSosMessage(location: Location?): String {
        val mapsLink = if (location != null) {
            "https://maps.google.com/?q=${location.latitude},${location.longitude}"
        } else {
            "Location unavailable"
        }
        return "EMERGENCY! I need help. My current location: $mapsLink"
    }

    private fun sendSms(phone: String, message: String) {
        try {
            val smsManager = getSystemService(SmsManager::class.java)
            smsManager.sendTextMessage(phone, null, message, null, null)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "SOS Alert",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Women Safety SOS Alerts"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, SosService::class.java).apply { action = ACTION_STOP },
            PendingIntent.FLAG_IMMUTABLE
        )
        val openIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SOS Active")
            .setContentText("Emergency alert sent to your contacts")
            .setSmallIcon(R.drawable.ic_sos)
            .setContentIntent(openIntent)
            .addAction(R.drawable.ic_close, "Stop SOS", stopIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .build()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
        LocationHelper.updateFirebaseSOS(null, false)
    }
}
