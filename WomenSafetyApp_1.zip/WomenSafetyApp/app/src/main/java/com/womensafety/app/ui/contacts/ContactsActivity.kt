package com.womensafety.app.ui.contacts

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.textfield.TextInputEditText
import com.womensafety.app.R
import com.womensafety.app.databinding.ActivityContactsBinding
import com.womensafety.app.model.Contact
import com.womensafety.app.viewmodel.MainViewModel

class ContactsActivity : AppCompatActivity() {

    private lateinit var binding: ActivityContactsBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: ContactsAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityContactsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        observeContacts()

        binding.fabAddContact.setOnClickListener { showAddContactDialog() }
        binding.toolbar.setNavigationOnClickListener { finish() }
    }

    private fun setupRecyclerView() {
        adapter = ContactsAdapter(
            onDelete = { contact -> viewModel.deleteContact(contact) }
        )
        binding.rvContacts.apply {
            layoutManager = LinearLayoutManager(this@ContactsActivity)
            adapter = this@ContactsActivity.adapter
        }
    }

    private fun observeContacts() {
        viewModel.contacts.observe(this) { contacts ->
            adapter.submitList(contacts)
            binding.tvEmpty.visibility = if (contacts.isEmpty())
                android.view.View.VISIBLE else android.view.View.GONE
        }
    }

    private fun showAddContactDialog() {
        val dialogView = layoutInflater.inflate(R.layout.dialog_add_contact, null)
        val nameInput = dialogView.findViewById<TextInputEditText>(R.id.etName)
        val phoneInput = dialogView.findViewById<TextInputEditText>(R.id.etPhone)
        val relationInput = dialogView.findViewById<TextInputEditText>(R.id.etRelation)

        MaterialAlertDialogBuilder(this)
            .setTitle("Add Emergency Contact")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                val name = nameInput.text.toString().trim()
                val phone = phoneInput.text.toString().trim()
                val relation = relationInput.text.toString().trim()
                if (name.isNotEmpty() && phone.isNotEmpty()) {
                    viewModel.addContact(Contact(name = name, phone = phone, relation = relation))
                } else {
                    Toast.makeText(this, "Name and phone are required", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
