package com.womensafety.app.ui.fakecall

import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Bundle
import android.os.CountDownTimer
import androidx.appcompat.app.AppCompatActivity
import com.womensafety.app.databinding.ActivityFakeCallBinding

class FakeCallActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFakeCallBinding
    private var ringtone: MediaPlayer? = null
    private var countdownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFakeCallBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val callerName = intent.getStringExtra("caller_name") ?: "Mom"
        val delaySeconds = intent.getIntExtra("delay_seconds", 0)

        if (delaySeconds > 0) {
            startCountdown(callerName, delaySeconds)
        } else {
            showIncomingCall(callerName)
        }
    }

    private fun startCountdown(callerName: String, seconds: Int) {
        binding.tvCallerName.text = "Incoming call in..."
        binding.tvStatus.text = "$seconds"
        countdownTimer = object : CountDownTimer(seconds * 1000L, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                binding.tvStatus.text = "${millisUntilFinished / 1000}"
            }
            override fun onFinish() {
                showIncomingCall(callerName)
            }
        }.start()
    }

    private fun showIncomingCall(callerName: String) {
        binding.tvCallerName.text = callerName
        binding.tvStatus.text = "Incoming call..."
        playRingtone()

        binding.btnAccept.setOnClickListener {
            stopRingtone()
            binding.tvStatus.text = "Call connected"
            binding.btnAccept.isEnabled = false
        }

        binding.btnDecline.setOnClickListener {
            stopRingtone()
            finish()
        }
    }

    private fun playRingtone() {
        val uri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
        ringtone = MediaPlayer.create(this, uri)
        ringtone?.isLooping = true
        ringtone?.start()
    }

    private fun stopRingtone() {
        ringtone?.stop()
        ringtone?.release()
        ringtone = null
    }

    override fun onDestroy() {
        super.onDestroy()
        stopRingtone()
        countdownTimer?.cancel()
    }
}
