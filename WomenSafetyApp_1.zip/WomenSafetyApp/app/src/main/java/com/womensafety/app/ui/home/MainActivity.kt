package com.womensafety.app.ui.home

import android.content.Intent
import android.os.Bundle
import android.os.CountDownTimer
import android.view.MotionEvent
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.womensafety.app.databinding.ActivityMainBinding
import com.womensafety.app.service.LocationTrackingService
import com.womensafety.app.service.SosService
import com.womensafety.app.ui.contacts.ContactsActivity
import com.womensafety.app.ui.fakecall.FakeCallActivity
import com.womensafety.app.ui.navigation.NavigationActivity
import com.womensafety.app.utils.PermissionHelper
import com.womensafety.app.viewmodel.MainViewModel

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()
    private var sosCountdownTimer: CountDownTimer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        requestPermissions()
        setupSosButton()
        setupButtons()
        observeViewModel()
    }

    private fun requestPermissions() {
        PermissionHelper.requestAllPermissions(this,
            onGranted = { Toast.makeText(this, "All permissions granted", Toast.LENGTH_SHORT).show() },
            onDenied = { Toast.makeText(this, "Some permissions denied. Features may not work.", Toast.LENGTH_LONG).show() }
        )
    }

    private fun setupSosButton() {
        // Hold 3 seconds to trigger SOS
        binding.btnSos.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startSosCountdown()
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    cancelSosCountdown()
                    true
                }
                else -> false
            }
        }
    }

    private fun startSosCountdown() {
        binding.tvSosHint.text = "Hold... 3"
        sosCountdownTimer = object : CountDownTimer(3000, 1000) {
            override fun onTick(millisUntilFinished: Long) {
                binding.tvSosHint.text = "Hold... ${millisUntilFinished / 1000 + 1}"
            }
            override fun onFinish() {
                triggerSOS()
            }
        }.start()
    }

    private fun cancelSosCountdown() {
        sosCountdownTimer?.cancel()
        binding.tvSosHint.text = "Hold 3 seconds to activate"
    }

    private fun triggerSOS() {
        val sosActive = viewModel.sosActive.value ?: false
        if (!sosActive) {
            SosService.start(this)
            viewModel.setSosActive(true)
            binding.btnSos.text = "SOS ACTIVE"
        } else {
            SosService.stop(this)
            viewModel.setSosActive(false)
            binding.btnSos.text = "SOS"
        }
    }

    private fun setupButtons() {
        binding.btnContacts.setOnClickListener {
            startActivity(Intent(this, ContactsActivity::class.java))
        }

        binding.btnShareLocation.setOnClickListener {
            val sharing = viewModel.locationSharing.value ?: false
            if (!sharing) {
                LocationTrackingService.start(this, System.currentTimeMillis().toString())
                viewModel.setLocationSharing(true)
                binding.btnShareLocation.text = "Stop Sharing"
            } else {
                LocationTrackingService.stop(this)
                viewModel.setLocationSharing(false)
                binding.btnShareLocation.text = "Share Location"
            }
        }

        binding.btnFakeCall.setOnClickListener {
            startActivity(Intent(this, FakeCallActivity::class.java))
        }

        binding.btnNavigation.setOnClickListener {
            startActivity(Intent(this, NavigationActivity::class.java))
        }
    }

    private fun observeViewModel() {
        viewModel.contacts.observe(this) { contacts ->
            binding.tvContactCount.text = "${contacts.size} emergency contacts"
        }
    }
}
