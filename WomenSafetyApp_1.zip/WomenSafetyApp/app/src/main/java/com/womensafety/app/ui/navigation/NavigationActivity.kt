package com.womensafety.app.ui.navigation

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.*
import com.womensafety.app.R
import com.womensafety.app.databinding.ActivityNavigationBinding
import com.womensafety.app.utils.PermissionHelper

class NavigationActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityNavigationBinding
    private lateinit var googleMap: GoogleMap

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityNavigationBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnStartNavigation.setOnClickListener {
            val destination = binding.etDestination.text.toString().trim()
            if (destination.isNotEmpty()) {
                Toast.makeText(this, "Navigating to $destination", Toast.LENGTH_SHORT).show()
                // Integrate Directions API here
            } else {
                Toast.makeText(this, "Enter a destination", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        if (PermissionHelper.hasLocationPermission(this)) {
            try {
                googleMap.isMyLocationEnabled = true
                googleMap.uiSettings.isMyLocationButtonEnabled = true
            } catch (e: SecurityException) {
                e.printStackTrace()
            }
        }
        // Default camera position (India)
        val defaultLocation = LatLng(17.3850, 78.4867)
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(defaultLocation, 12f))
    }
}
