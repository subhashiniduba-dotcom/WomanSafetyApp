package com.womensafety.app.utils

import android.annotation.SuppressLint
import android.content.Context
import android.location.Location
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

object LocationHelper {

    @SuppressLint("MissingPermission")
    suspend fun getLastLocation(
        context: Context,
        fusedLocationClient: FusedLocationProviderClient
    ): Location? = suspendCancellableCoroutine { cont ->
        fusedLocationClient.lastLocation
            .addOnSuccessListener { location -> cont.resume(location) }
            .addOnFailureListener { cont.resume(null) }
    }

    fun updateFirebaseLocation(sessionId: String, location: Location) {
        val db = FirebaseDatabase.getInstance().reference
        val data = mapOf(
            "lat" to location.latitude,
            "lng" to location.longitude,
            "timestamp" to System.currentTimeMillis(),
            "accuracy" to location.accuracy
        )
        db.child("tracking").child(sessionId).setValue(data)
    }

    fun updateFirebaseSOS(location: Location?, isActive: Boolean) {
        val db = FirebaseDatabase.getInstance().reference
        val data = mapOf(
            "active" to isActive,
            "lat" to (location?.latitude ?: 0.0),
            "lng" to (location?.longitude ?: 0.0),
            "timestamp" to System.currentTimeMillis()
        )
        db.child("sos").setValue(data)
    }

    fun buildMapsLink(lat: Double, lng: Double): String =
        "https://maps.google.com/?q=$lat,$lng"
}
