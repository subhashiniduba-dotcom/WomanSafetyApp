package com.womensafety.app.utils

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.content.ContextCompat
import com.permissionx.guolindev.PermissionX

object PermissionHelper {

    val REQUIRED_PERMISSIONS = listOf(
        Manifest.permission.ACCESS_FINE_LOCATION,
        Manifest.permission.ACCESS_COARSE_LOCATION,
        Manifest.permission.SEND_SMS,
        Manifest.permission.READ_CONTACTS,
        Manifest.permission.CALL_PHONE
    )

    fun hasLocationPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

    fun hasSmsPermission(context: Context): Boolean =
        ContextCompat.checkSelfPermission(
            context, Manifest.permission.SEND_SMS
        ) == PackageManager.PERMISSION_GRANTED

    fun requestAllPermissions(activity: Activity, onGranted: () -> Unit, onDenied: () -> Unit) {
        PermissionX.init(activity)
            .permissions(REQUIRED_PERMISSIONS)
            .onExplainRequestReason { scope, deniedList ->
                scope.showRequestReasonDialog(
                    deniedList,
                    "These permissions are required for your safety features to work.",
                    "OK", "Cancel"
                )
            }
            .request { allGranted, _, _ ->
                if (allGranted) onGranted() else onDenied()
            }
    }
}
