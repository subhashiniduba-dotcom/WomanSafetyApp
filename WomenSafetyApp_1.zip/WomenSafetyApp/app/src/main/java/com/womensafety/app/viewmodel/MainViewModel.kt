package com.womensafety.app.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.womensafety.app.model.Contact
import com.womensafety.app.repository.ContactRepository
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = ContactRepository(application)

    private val _contacts = MutableLiveData<List<Contact>>()
    val contacts: LiveData<List<Contact>> = _contacts

    private val _sosActive = MutableLiveData(false)
    val sosActive: LiveData<Boolean> = _sosActive

    private val _locationSharing = MutableLiveData(false)
    val locationSharing: LiveData<Boolean> = _locationSharing

    init {
        loadContacts()
    }

    fun loadContacts() {
        viewModelScope.launch {
            _contacts.postValue(repository.getAllContacts())
        }
    }

    fun addContact(contact: Contact) {
        viewModelScope.launch {
            repository.insertContact(contact)
            loadContacts()
        }
    }

    fun deleteContact(contact: Contact) {
        viewModelScope.launch {
            repository.deleteContact(contact)
            loadContacts()
        }
    }

    fun setSosActive(active: Boolean) {
        _sosActive.postValue(active)
    }

    fun setLocationSharing(active: Boolean) {
        _locationSharing.postValue(active)
    }
}
