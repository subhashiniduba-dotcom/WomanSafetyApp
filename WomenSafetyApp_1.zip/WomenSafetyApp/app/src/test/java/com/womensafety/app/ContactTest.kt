package com.womensafety.app

import com.womensafety.app.model.Contact
import org.junit.Assert.*
import org.junit.Test

class ContactTest {

    @Test
    fun `contact name should not be empty`() {
        val contact = Contact(name = "Priya", phone = "9876543210", relation = "Mom")
        assertTrue(contact.name.isNotEmpty())
    }

    @Test
    fun `contact phone should be numeric`() {
        val contact = Contact(name = "Priya", phone = "9876543210")
        assertTrue(contact.phone.all { it.isDigit() })
    }

    @Test
    fun `default contact is not primary`() {
        val contact = Contact(name = "Priya", phone = "9876543210")
        assertFalse(contact.isPrimary)
    }

    @Test
    fun `sos message contains maps link`() {
        val lat = 17.3850
        val lng = 78.4867
        val link = "https://maps.google.com/?q=$lat,$lng"
        val message = "EMERGENCY! I need help. My current location: $link"
        assertTrue(message.contains("maps.google.com"))
        assertTrue(message.contains("EMERGENCY"))
    }
}
